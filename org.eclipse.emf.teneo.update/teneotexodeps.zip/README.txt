Category generation does not work correctly:
http://ekkescorner.wordpress.com/2010/04/18/who-eats-the-categories-from-update-sites/
http://eclipsesource.com/blogs/2009/05/08/categorize-your-repository/

What seems to work is to remove the contents.jar and artifacts.jar files.